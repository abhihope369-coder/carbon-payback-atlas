"""Public electricity lifecycle-intensity data access and validation."""
from __future__ import annotations

import pandas as pd

OWID_URL = (
    "https://ourworldindata.org/grapher/electricity-mix.csv"
    "?v=1&csvType=full&useColumnShortNames=false&source=total"
    "&metric=carbon_intensity&frequency=annual"
)


def normalize_electricity_data(frame: pd.DataFrame) -> pd.DataFrame:
    """Normalize an OWID Grapher CSV (or compatible file) to a stable schema."""
    candidates = [
        c for c in frame.columns
        if "lifecycle carbon intensity" in str(c).lower()
        or "carbon_intensity" in str(c).lower()
        or "carbon intensity" in str(c).lower()
    ]
    if not candidates:
        raise ValueError(
            "Could not identify the lifecycle carbon-intensity column. "
            f"Available columns: {list(frame.columns)}"
        )
    if not {"Entity", "Year"}.issubset(frame.columns):
        raise ValueError("Dataset must contain Entity and Year columns.")
    cols = [c for c in ["Entity", "Code", "Year", candidates[0]] if c in frame.columns]
    out = frame[cols].copy().rename(columns={candidates[0]: "intensity_gco2_kwh"})
    out["Year"] = pd.to_numeric(out["Year"], errors="coerce")
    out["intensity_gco2_kwh"] = pd.to_numeric(out["intensity_gco2_kwh"], errors="coerce")
    out = out.dropna(subset=["Entity", "Year", "intensity_gco2_kwh"])
    out["Year"] = out["Year"].astype(int)
    out = out[out["intensity_gco2_kwh"] >= 0]
    out = out.drop_duplicates(["Entity", "Year"], keep="last")
    return out.sort_values(["Entity", "Year"]).reset_index(drop=True)


def load_electricity_data(url: str = OWID_URL) -> pd.DataFrame:
    """Download annual lifecycle electricity intensity in gCO2e/kWh."""
    raw = pd.read_csv(
        url,
        storage_options={"User-Agent": "Carbon Payback Atlas educational prototype/1.0"},
    )
    return normalize_electricity_data(raw)
