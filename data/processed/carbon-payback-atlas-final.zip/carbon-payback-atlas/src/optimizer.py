"""Integer budget allocation using SciPy's HiGHS mixed-integer optimizer."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix


def build_options(region_intensity_by_year: dict[str, dict[int, float]], deployment_years: list[int],
                  target_year: int, vehicle_cost: float, annual_km: float,
                  petrol_kg_per_km: float, ev_kwh_per_km: float,
                  additional_manufacturing_kg: float, max_vehicles_per_region: int = 500,
                  petrol_upstream_kg_per_km: float = 0.0,
                  ev_upstream_multiplier: float = 1.0) -> pd.DataFrame:
    """Build one decision variable per region/year, measured per vehicle."""
    if vehicle_cost <= 0 or max_vehicles_per_region < 1:
        raise ValueError("Vehicle cost and regional capacity must be positive.")
    if not deployment_years:
        return pd.DataFrame()
    rows = []
    for region, year_map in region_intensity_by_year.items():
        for deploy_year in deployment_years:
            if deploy_year > target_year or deploy_year not in year_map:
                continue
            years = range(deploy_year, target_year + 1)
            grid_values = [float(year_map.get(y, year_map[max(year_map)])) for y in years]
            petrol_annual = annual_km * (petrol_kg_per_km + petrol_upstream_kg_per_km)
            ev_annual = [annual_km * ev_kwh_per_km * (g / 1000) * ev_upstream_multiplier for g in grid_values]
            net = sum(petrol_annual - x for x in ev_annual) - additional_manufacturing_kg
            rows.append({
                "Region": region, "Deployment year": int(deploy_year),
                "Cost per vehicle ($)": float(vehicle_cost),
                "Net savings per vehicle (kgCO2e)": float(net),
                "Max vehicles": int(max_vehicles_per_region),
            })
    return pd.DataFrame(rows)


def optimize_allocation(options: pd.DataFrame, budget: float,
                        max_vehicles_per_region: int | None = None,
                        max_vehicles_per_year: int | None = None) -> tuple[pd.DataFrame, dict]:
    """Maximize net CO2e savings with integer vehicle counts and capacity limits."""
    if budget < 0:
        raise ValueError("Budget cannot be negative.")
    if options.empty:
        return options.copy(), {"status": "No candidate options", "spend": 0.0, "savings": 0.0}
    o = options.reset_index(drop=True).copy()
    n = len(o)
    # Non-beneficial options are excluded: deploying them would reduce net savings.
    objective = -o["Net savings per vehicle (kgCO2e)"].to_numpy(dtype=float)
    upper = np.full(n, float(max_vehicles_per_region or 500))
    upper = np.minimum(upper, o["Max vehicles"].to_numpy(dtype=float))
    upper = np.where(objective < 0, upper, 0.0)
    constraints_rows = []
    constraints_upper = []
    # Total spend <= budget.
    constraints_rows.append(o["Cost per vehicle ($)"].to_numpy(dtype=float))
    constraints_upper.append(float(budget))
    # Regional capacity shared across all deployment years.
    if max_vehicles_per_region is not None:
        for _, indices in o.groupby("Region").groups.items():
            row = np.zeros(n); row[list(indices)] = 1
            constraints_rows.append(row); constraints_upper.append(float(max_vehicles_per_region))
    # Annual deployment capacity shared across regions.
    if max_vehicles_per_year is not None:
        for _, indices in o.groupby("Deployment year").groups.items():
            row = np.zeros(n); row[list(indices)] = 1
            constraints_rows.append(row); constraints_upper.append(float(max_vehicles_per_year))
    A = np.vstack(constraints_rows)
    result = milp(
        c=objective,
        integrality=np.ones(n),
        bounds=Bounds(np.zeros(n), upper),
        constraints=LinearConstraint(A, np.full(A.shape[0], -np.inf), np.asarray(constraints_upper)),
        options={"time_limit": 15.0},
    )
    if not result.success or result.x is None:
        return pd.DataFrame(), {"status": result.message, "spend": 0.0, "savings": 0.0}
    o["Vehicles allocated"] = np.rint(result.x).astype(int)
    o = o[o["Vehicles allocated"] > 0].copy()
    o["Total cost ($)"] = o["Vehicles allocated"] * o["Cost per vehicle ($)"]
    o["Estimated net savings (kgCO2e)"] = o["Vehicles allocated"] * o["Net savings per vehicle (kgCO2e)"]
    o = o.sort_values(["Deployment year", "Region"]).reset_index(drop=True)
    summary = {
        "status": result.message,
        "spend": float(o["Total cost ($)"].sum()) if not o.empty else 0.0,
        "savings": float(o["Estimated net savings (kgCO2e)"].sum()) if not o.empty else 0.0,
        "vehicles": int(o["Vehicles allocated"].sum()) if not o.empty else 0,
        "optimal": bool(result.success),
    }
    return o, summary


def greedy_optimize(options: pd.DataFrame, budget: float) -> pd.DataFrame:
    """Backward-compatible wrapper; now delegates to exact integer optimization."""
    if options.empty:
        return options.copy()
    converted = options.rename(columns={
        "Cost ($)": "Cost per vehicle ($)",
        "Savings per dollar": "_unused_ratio",
        "Estimated net savings (kg CO2e)": "Net savings per vehicle (kgCO2e)",
    }).copy()
    if "Max vehicles" not in converted:
        converted["Max vehicles"] = 1
    selected, _ = optimize_allocation(converted, budget, max_vehicles_per_region=1)
    return selected
