"""Carbon Payback Atlas application modules."""
