"""Transparent EV-versus-petrol use-phase and manufacturing payback model."""
from __future__ import annotations
import pandas as pd


def lifecycle_comparison(
    grid_forecast_g_per_kwh: list[float], annual_km: float = 15000,
    petrol_kg_per_km: float = 0.192, ev_kwh_per_km: float = 0.18,
    additional_manufacturing_kg: float = 5000, lifetime_years: int = 12,
    petrol_upstream_kg_per_km: float = 0.0, ev_upstream_multiplier: float = 1.0,
):
    """Calculate annual emissions and cumulative net savings for one vehicle.

    Petrol factor can include tailpipe only or a well-to-wheel factor; the user
    must choose a consistent boundary. EV grid intensity is gCO2e/kWh. The
    manufacturing input is the *incremental* EV-minus-petrol manufacturing
    burden, not total EV manufacturing emissions.
    """
    vals = [annual_km, petrol_kg_per_km, ev_kwh_per_km,
            additional_manufacturing_kg, petrol_upstream_kg_per_km,
            ev_upstream_multiplier]
    if any(v < 0 for v in vals) or ev_upstream_multiplier < 1:
        raise ValueError("Inputs must be non-negative; EV upstream multiplier must be at least 1.")
    if lifetime_years < 1 or not grid_forecast_g_per_kwh:
        raise ValueError("A positive lifetime and at least one grid-intensity value are required.")
    if any(float(x) < 0 for x in grid_forecast_g_per_kwh):
        raise ValueError("Grid intensity cannot be negative.")
    rows, cumulative = [], 0.0
    for i in range(lifetime_years):
        grid_g = float(grid_forecast_g_per_kwh[min(i, len(grid_forecast_g_per_kwh) - 1)])
        petrol = annual_km * (petrol_kg_per_km + petrol_upstream_kg_per_km)
        ev = annual_km * ev_kwh_per_km * (grid_g / 1000.0) * ev_upstream_multiplier
        saving = petrol - ev
        cumulative += saving
        net = cumulative - additional_manufacturing_kg
        rows.append({
            "Year of ownership": i + 1,
            "Grid intensity (gCO2e/kWh)": grid_g,
            "Petrol operational emissions (kgCO2e)": petrol,
            "EV charging emissions (kgCO2e)": ev,
            "Annual operational savings (kgCO2e)": saving,
            "Cumulative net savings (kgCO2e)": net,
        })
    result = pd.DataFrame(rows)
    paid = result[result["Cumulative net savings (kgCO2e)"] >= 0]
    payback = int(paid.iloc[0]["Year of ownership"]) if not paid.empty else None
    return result, payback
