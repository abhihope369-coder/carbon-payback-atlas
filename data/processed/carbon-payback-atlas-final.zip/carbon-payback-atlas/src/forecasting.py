"""Leakage-aware temporal validation and short-horizon grid-intensity forecasts."""
from __future__ import annotations

import warnings
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ["year", "lag_1", "lag_2", "lag_3"]


def _prepare(series: pd.DataFrame) -> pd.DataFrame:
    s = series[["Year", "intensity_gco2_kwh"]].copy()
    s["Year"] = pd.to_numeric(s["Year"], errors="coerce")
    s["intensity_gco2_kwh"] = pd.to_numeric(s["intensity_gco2_kwh"], errors="coerce")
    s = s.dropna().sort_values("Year").drop_duplicates("Year").reset_index(drop=True)
    if len(s) and not np.all(np.diff(s["Year"].to_numpy()) == 1):
        warnings.warn("The historical series has missing calendar years; lag features use previous available observations.")
    s["year"] = s["Year"].astype(float)
    for lag in (1, 2, 3):
        s[f"lag_{lag}"] = s["intensity_gco2_kwh"].shift(lag)
    return s.dropna().reset_index(drop=True)


def _models(seed: int = 42):
    return {
        "Random Forest": RandomForestRegressor(
            n_estimators=350, max_depth=5, min_samples_leaf=2,
            max_features=1.0, random_state=seed, n_jobs=-1,
        ),
        "Extra Trees": ExtraTreesRegressor(
            n_estimators=350, max_depth=5, min_samples_leaf=2,
            max_features=1.0, random_state=seed, n_jobs=-1,
        ),
        "Ridge Regression": make_pipeline(StandardScaler(), Ridge(alpha=2.0)),
    }


def fit_and_forecast(series: pd.DataFrame, horizon: int = 10, min_train: int = 8):
    """Select a model using a chronological holdout, refit, and recursively forecast.

    The holdout is the latest 20% (at least two observations), and is never
    randomly shuffled. A persistence forecast is retained as a benchmark.
    Prediction intervals are empirical residual bands, widened with horizon;
    they are diagnostic bands, not formal probabilistic guarantees.
    """
    if horizon < 1:
        raise ValueError("Forecast horizon must be at least one year.")
    s = _prepare(series)
    if len(s) < min_train + 2:
        raise ValueError(f"Need at least {min_train + 5} usable annual observations; found {len(s) + 3}.")
    split = max(min_train, int(np.floor(len(s) * 0.8)))
    split = min(split, len(s) - 2)
    train, test = s.iloc[:split], s.iloc[split:]
    results = []
    fitted = {}
    for name, estimator in _models().items():
        estimator.fit(train[FEATURES], train["intensity_gco2_kwh"])
        pred = np.maximum(0, estimator.predict(test[FEATURES]))
        fitted[name] = estimator
        results.append({
            "Model": name,
            "MAE (gCO2e/kWh)": mean_absolute_error(test["intensity_gco2_kwh"], pred),
            "RMSE (gCO2e/kWh)": np.sqrt(mean_squared_error(test["intensity_gco2_kwh"], pred)),
        })
    baseline = test["lag_1"].to_numpy(dtype=float)
    results.append({
        "Model": "Persistence baseline",
        "MAE (gCO2e/kWh)": mean_absolute_error(test["intensity_gco2_kwh"], baseline),
        "RMSE (gCO2e/kWh)": np.sqrt(mean_squared_error(test["intensity_gco2_kwh"], baseline)),
    })
    leaderboard = pd.DataFrame(results).sort_values("MAE (gCO2e/kWh)").reset_index(drop=True)
    chosen_name = str(leaderboard.iloc[0]["Model"])
    if chosen_name == "Persistence baseline":
        chosen = None
        test_predictions = baseline
        forecast_name = "Persistence baseline"
    else:
        chosen = _models()[chosen_name]
        chosen.fit(s[FEATURES], s["intensity_gco2_kwh"])
        test_predictions = np.maximum(0, fitted[chosen_name].predict(test[FEATURES]))
        forecast_name = chosen_name
    residuals = test["intensity_gco2_kwh"].to_numpy(dtype=float) - test_predictions
    abs_resid = np.abs(residuals)
    q = float(np.quantile(abs_resid, 0.90)) if len(abs_resid) else 0.0
    metrics = {
        "model": forecast_name,
        "mae": float(mean_absolute_error(test["intensity_gco2_kwh"], test_predictions)),
        "rmse": float(np.sqrt(mean_squared_error(test["intensity_gco2_kwh"], test_predictions))),
        "r2": float(r2_score(test["intensity_gco2_kwh"], test_predictions)) if len(test) > 1 else float("nan"),
        "baseline_mae": float(mean_absolute_error(test["intensity_gco2_kwh"], baseline)),
        "test_start": int(test["Year"].min()),
        "test_end": int(test["Year"].max()),
        "n_test": int(len(test)),
        "residual_q90": q,
        "leaderboard": leaderboard,
    }
    history = s[["Year", "intensity_gco2_kwh"]].copy()
    future_rows = []
    last_year = int(history["Year"].max())
    for step in range(1, horizon + 1):
        vals = history["intensity_gco2_kwh"].to_numpy(dtype=float)
        if chosen is None:
            prediction = float(vals[-1])
        else:
            row = pd.DataFrame([{
                "year": last_year + step,
                "lag_1": vals[-1], "lag_2": vals[-2], "lag_3": vals[-3],
            }])
            prediction = float(chosen.predict(row[FEATURES])[0])
        prediction = max(0.0, prediction)
        band = q * np.sqrt(step)
        future_rows.append({
            "Year": last_year + step,
            "intensity_gco2_kwh": prediction,
            "lower_gco2_kwh": max(0.0, prediction - band),
            "upper_gco2_kwh": prediction + band,
            "kind": "Forecast",
        })
        history = pd.concat([history, pd.DataFrame([{"Year": last_year + step, "intensity_gco2_kwh": prediction}])], ignore_index=True)
    historical = s[["Year", "intensity_gco2_kwh"]].copy()
    historical["kind"] = "Historical"
    return chosen, historical, pd.DataFrame(future_rows), metrics
