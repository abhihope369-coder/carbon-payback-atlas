# Carbon Payback Atlas

**AI-powered climate technology deployment intelligence — EV fleet transition edition.**

Carbon Payback Atlas is an interactive decision-support prototype for exploring where and when electric-vehicle fleet investments could produce the greatest *estimated* net greenhouse-gas savings. It combines public annual electricity lifecycle-intensity observations, temporal model validation and forecasting, a transparent EV-versus-petrol lifecycle calculator, and an integer budget-allocation optimizer.

> The application is a research and educational prototype. It does not make verified real-world impact claims, guarantee future grid intensity, or provide procurement or investment advice.

## Features

1. **Global Atlas** — interactive country-level choropleth of each geography's latest available annual lifecycle electricity intensity, region comparison, and latest-year context.
2. **Grid Future AI** — chronological holdout validation of Random Forest, Extra Trees, Ridge Regression and a persistence baseline; automatic model selection by holdout MAE; recursive forecast; empirical residual diagnostic band; CSV export.
3. **Fleet Lab** — editable vehicle assumptions, year-by-year petrol and EV use-phase emissions, incremental manufacturing burden, cumulative net savings, and estimated carbon-payback year.
4. **Deployment Optimizer** — region-specific forecast-year alignment and integer linear optimization using SciPy/HiGHS. Decision variables are integer EV counts per region/deployment year. Constraints include budget, maximum vehicles per region and maximum deployments per year. Compares forecast-aware allocation with a constant-current-intensity strategy.
5. **Strategy Report & Methods** — downloadable scenario report, data provenance, model validation details, boundaries and limitations.

## Run locally

Python 3.10+ is recommended.

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit (usually http://localhost:8501). Internet access is required to download the public dataset unless you upload a compatible CSV.

## Data source and schema

The default loader uses the Our World in Data Grapher electricity lifecycle carbon-intensity series (Ember source). The app normalizes the file to:

- `Entity`: country/geography name
- `Code`: geography code, when supplied
- `Year`: calendar year
- `intensity_gco2_kwh`: lifecycle electricity intensity in gCO2e/kWh

Dataset page: https://ourworldindata.org/grapher/electricity-mix?frequency=annual&metric=carbon_intensity&source=total

A compatible user CSV can also be uploaded in the sidebar. It must include `Entity`, `Year`, and a carbon-intensity column whose name includes `lifecycle carbon intensity`, `carbon_intensity`, or `carbon intensity`.

## Forecast methodology

- Annual observations are sorted chronologically and lag features are constructed from the previous three available observations.
- The latest chronological portion (at least two observations) is held out. No random shuffle is used.
- Random Forest, Extra Trees and Ridge Regression are evaluated against a persistence baseline.
- The model with the lowest holdout MAE is refit on all available history and recursively forecasts future annual intensity.
- The forecast band is based on the 90th percentile of absolute holdout residuals and widens with the square root of forecast horizon.

The band is a rough diagnostic, **not** a calibrated statistical prediction interval. The forecasting features do not include future policy, generation projects, fuel prices, load, weather, storage, or grid dispatch. Long-range extrapolations can be unreliable. The model should be judged against the baseline and interpreted with these limitations in mind.

## Lifecycle accounting

For each year of vehicle ownership:

- Petrol comparator emissions = annual kilometres × (petrol factor + optional upstream petrol factor).
- EV charging emissions = annual kilometres × EV kWh/km × grid intensity (g/kWh ÷ 1000) × optional EV grid lifecycle multiplier.
- Annual operational savings = petrol comparator emissions − EV charging emissions.
- Cumulative net savings = cumulative operational savings − incremental EV-minus-petrol manufacturing burden.
- Carbon payback is the first ownership year when cumulative net savings are at least zero.

The user-entered petrol factor must have a clearly chosen boundary (tailpipe-only or well-to-wheel). Do not double count upstream petrol emissions. The manufacturing input is the *difference* in manufacturing emissions between the EV and petrol comparator, not total EV manufacturing emissions.

Not automatically included: vehicle/battery replacement, maintenance, disposal, recycling credits, roads, charging infrastructure, marginal hourly grid intensity, induced travel, or financing and operating costs. The default annual grid intensity is an average lifecycle metric, not a marginal charging emissions estimate.

## Optimizer formulation

Let `x[r,t]` be integer EVs deployed in region `r` during year `t`, `s[r,t]` be estimated net savings per vehicle by the target year, `c` be the assumed purchase cost per vehicle, `B` the budget, `K[r]` the regional deployment cap and `C[t]` the annual deployment cap.

Maximize:

`sum(x[r,t] * s[r,t])`

Subject to:

- `sum(x[r,t] * c) <= B`
- `sum_t x[r,t] <= K[r]`
- `sum_r x[r,t] <= C[t]`
- `x[r,t]` is a non-negative integer.

The application solves this mixed-integer linear program with SciPy's HiGHS-backed `milp`. Options with non-positive estimated net savings are not selected. The forecast-aware and constant-current-intensity strategies use the same assumptions and constraints.

This is still a simplified planning model. It assumes a common cost per EV, fixed per-region and per-year capacity limits, no discounting, no salvage value, no vehicle heterogeneity, no charging-site constraints, and no uncertain cost or policy scenarios. Optimizer output is conditional on the selected inputs and forecast model.

## Testing

Run:

```bash
pytest -q
```

Tests cover dataset normalization, lifecycle payback behavior, non-empty input validation, integer optimizer budget/capacity constraints, and future forecast generation.

## Project structure

```text
carbon-payback-atlas/
├── app.py
├── requirements.txt
├── README.md
├── src/
│   ├── __init__.py
│   ├── data.py
│   ├── forecasting.py
│   ├── lifecycle.py
│   └── optimizer.py
└── tests/
    └── test_core.py
```

## Responsible interpretation

Historical observations, model forecasts, user-entered assumptions, and optimizer recommendations are distinct data types. Keep them labelled. Do not describe forecast savings as measured emissions reductions or claim that an optimized allocation caused a real-world outcome. Validate data coverage, factor boundaries and model performance before any real procurement decision.
