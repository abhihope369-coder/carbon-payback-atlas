# Two-minute demo script

**0:00–0:15 — Problem**  
"Organizations have limited budgets for climate action. For an EV fleet transition, the emissions benefit depends partly on where vehicles are deployed, when they are deployed, and how clean the electricity grid becomes. A static carbon calculator cannot compare all of those decisions together."

**0:15–0:35 — Atlas and forecast**  
"Carbon Payback Atlas starts with public annual electricity lifecycle-intensity data. In Grid Future AI, I compare Random Forest, Extra Trees and Ridge Regression on a chronological holdout, and I benchmark them against a persistence baseline. The model with the lowest holdout MAE is used for the forecast."

**0:35–0:55 — Lifecycle and payback**  
"The Fleet Lab compares petrol use-phase emissions with EV charging emissions and adds the incremental manufacturing burden. It calculates cumulative net savings and identifies the first year that the EV option reaches carbon payback under the chosen assumptions."

**0:55–1:25 — Optimization**  
"The main decision feature is the deployment optimizer. It treats the number of EVs assigned to each region and year as integer decision variables. It maximizes estimated net savings while respecting a total budget, regional capacity and annual deployment capacity."

**1:25–1:45 — Strategy comparison**  
"I compare the forecast-aware strategy with a reference strategy that holds each region's latest observed grid intensity constant. Both use the same vehicle assumptions, budget and constraints. The comparison shows how future grid trajectories can change the recommended allocation."

**1:45–2:00 — Honesty and impact**  
"The results are estimates, not guaranteed emissions reductions. The dashboard separates observations, forecasts and user assumptions, reports validation error, and documents lifecycle boundaries. The goal is to make climate investment decisions more transparent and evidence-based."
