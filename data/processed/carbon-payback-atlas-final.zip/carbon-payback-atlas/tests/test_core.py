import numpy as np
import pandas as pd
import pytest
from src.data import normalize_electricity_data
from src.lifecycle import lifecycle_comparison
from src.optimizer import build_options, optimize_allocation
from src.forecasting import fit_and_forecast


def test_normalize_owid_style_data():
    raw = pd.DataFrame({"Entity":["Canada","Canada"],"Code":["CAN","CAN"],"Year":[2020,2021],"Lifecycle carbon intensity of electricity - gCO₂/kWh":[120,110]})
    out = normalize_electricity_data(raw)
    assert list(out.columns) == ["Entity","Code","Year","intensity_gco2_kwh"]
    assert out.iloc[-1]["intensity_gco2_kwh"] == 110


def test_lifecycle_payback_and_no_payback():
    result, payback = lifecycle_comparison([400,350,300,250,200,150], lifetime_years=6)
    assert len(result) == 6
    assert payback is not None
    _, no_payback = lifecycle_comparison([2000]*6, lifetime_years=6)
    assert no_payback is None


def test_lifecycle_rejects_empty_grid_series():
    with pytest.raises(ValueError):
        lifecycle_comparison([], lifetime_years=4)


def test_optimizer_budget_and_integer_constraints():
    options = pd.DataFrame([
        {"Region":"A","Deployment year":2027,"Cost per vehicle ($)":50000,"Net savings per vehicle (kgCO2e)":12000,"Max vehicles":20},
        {"Region":"B","Deployment year":2027,"Cost per vehicle ($)":60000,"Net savings per vehicle (kgCO2e)":16000,"Max vehicles":20},
        {"Region":"A","Deployment year":2028,"Cost per vehicle ($)":50000,"Net savings per vehicle (kgCO2e)":10000,"Max vehicles":20},
    ])
    chosen, summary = optimize_allocation(options, 600000, max_vehicles_per_region=10, max_vehicles_per_year=8)
    assert summary["spend"] <= 600000 + 1e-6
    assert summary["vehicles"] == int(summary["vehicles"])
    assert chosen["Vehicles allocated"].sum() <= 16
    assert chosen.groupby("Region")["Vehicles allocated"].sum().max() <= 10
    assert chosen.groupby("Deployment year")["Vehicles allocated"].sum().max() <= 8


def test_forecast_is_future_only_and_nonnegative():
    years = np.arange(1990, 2021)
    values = np.linspace(600, 300, len(years)) + np.sin(np.arange(len(years))) * 12
    series = pd.DataFrame({"Year":years,"intensity_gco2_kwh":values})
    _, hist, future, metrics = fit_and_forecast(series, horizon=5)
    assert len(future) == 5
    assert future["Year"].min() == 2021
    assert (future["intensity_gco2_kwh"] >= 0).all()
    assert metrics["n_test"] >= 2
    assert set(hist["kind"]) == {"Historical"}
