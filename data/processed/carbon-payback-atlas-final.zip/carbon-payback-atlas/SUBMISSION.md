# Carbon Payback Atlas

**The right climate investment. In the right place. At the right time.**

## Project summary

Carbon Payback Atlas is an AI-powered climate technology deployment decision-support prototype. It investigates a practical question: when an organization has a limited budget to replace petrol fleet vehicles with electric vehicles, how can it compare locations and deployment years to maximize estimated net greenhouse-gas savings?

The application links three technical components that are often explored separately:

1. **Grid Future AI:** compares several machine-learning/statistical models using a chronological holdout and forecasts future annual electricity lifecycle carbon intensity.
2. **Carbon Payback Engine:** estimates annual petrol and EV charging emissions, accounts for the incremental EV manufacturing burden, and identifies the estimated carbon-payback year.
3. **Deployment Optimizer:** uses integer linear optimization to allocate EV purchases across candidate regions and deployment years under budget and capacity constraints.

The result is an interactive workflow from public electricity data to validated forecasting, lifecycle accounting, and a constrained investment strategy.

## What makes the approach useful

A region's electricity mix affects the emissions associated with EV charging. A region with a high current electricity intensity may decarbonize over time, while another region may have a lower current intensity but a different trajectory. Looking only at today's grid intensity can therefore miss how deployment timing affects cumulative emissions. Carbon Payback Atlas makes the forecast assumption explicit, compares a forecast-aware strategy against a constant-current-intensity reference, and keeps the same fleet and budget assumptions for both strategies.

The project does not claim that forecasting alone determines the best climate investment. It exposes the assumptions and allows users to inspect the evidence and trade-offs.

## Technical implementation

- Python, Pandas and NumPy for data processing and calculations.
- Scikit-learn for Random Forest, Extra Trees and Ridge Regression models.
- Chronological holdout evaluation with MAE, RMSE and a persistence baseline.
- Plotly and Streamlit for interactive data exploration and dashboard views.
- SciPy's HiGHS-backed mixed-integer linear programming solver for integer vehicle allocations.
- Pytest for calculation, normalization, forecasting and optimization tests.

## Demo sequence

1. Open the Global Atlas and compare the latest available grid-intensity observations.
2. Select a primary region and inspect its historical data.
3. Open Grid Future AI and compare holdout errors for the candidate models and persistence baseline.
4. Inspect the forecast and its diagnostic residual band.
5. Open Fleet Lab and change annual distance, petrol factor, EV efficiency, manufacturing difference and lifetime.
6. Show the annual emissions table, cumulative net savings and carbon-payback year.
7. Open Deployment Optimizer, select candidate regions, set budget and capacities, and run the optimization.
8. Compare the forecast-aware allocation with the current-intensity reference using the same constraints.
9. Download the allocation and strategy report, then show the assumptions and limitations.

## Responsible-use statement

All outputs are scenario estimates. Forecasts are not official energy-system scenarios or guarantees. Lifecycle results depend on user-entered emissions factors and system boundaries. Optimizer recommendations are conditional on the selected data and assumptions. No actual fleet transition, partnership, or realized emissions reduction is claimed.
