from __future__ import annotations

import io
from datetime import datetime
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src.data import load_electricity_data, normalize_electricity_data
from src.forecasting import fit_and_forecast
from src.lifecycle import lifecycle_comparison
from src.optimizer import build_options, optimize_allocation

st.set_page_config(page_title="Carbon Payback Atlas", page_icon="🌍", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root{--ink:#edf5f6;--muted:#9db3bc;--panel:#10222d;--line:#23414d;--mint:#64d6b5;--gold:#e7c47c;}
.stApp{background:radial-gradient(circle at 12% 0%,#17434a 0%,#0a1a24 36%,#07131b 100%);color:var(--ink);font-family:'DM Sans',sans-serif}
[data-testid="stSidebar"]{background:#091923;border-right:1px solid var(--line)}
.block-container{padding-top:1.5rem;max-width:1500px}
h1,h2,h3{font-family:'Space Grotesk',sans-serif;letter-spacing:-.025em}
.hero{padding:27px 31px;border:1px solid #2c5b62;border-radius:20px;background:linear-gradient(115deg,rgba(22,83,78,.76),rgba(12,31,44,.95));margin-bottom:18px}
.eyebrow{color:var(--mint);letter-spacing:.18em;font-size:.72rem;font-weight:700}
.hero h1{font-size:2.45rem;margin:.25rem 0;color:#f4fbff}
.hero p{color:#c1d5d9;font-size:1.03rem;margin:0}
.small-note{color:var(--muted);font-size:.86rem}
div[data-testid="stMetric"]{background:rgba(16,34,45,.82);border:1px solid var(--line);padding:14px 17px;border-radius:14px}
.stTabs [data-baseweb="tab-list"]{gap:8px}
.stTabs [data-baseweb="tab"]{background:#10232e;border-radius:10px 10px 0 0;padding:10px 16px}
.stButton>button[kind="primary"]{background:#167d6c;border:1px solid #54c8a8;color:white}
hr{border-color:#25414b}
</style>
<div class="hero"><div class="eyebrow">CLIMATE INVESTMENT INTELLIGENCE · EV FLEET EDITION</div><h1>Carbon Payback Atlas</h1><p>The right climate investment. In the right place. At the right time.</p></div>
""", unsafe_allow_html=True)

@st.cache_data(ttl=3600, show_spinner=False)
def cached_public_data():
    return load_electricity_data()

@st.cache_data(show_spinner=False)
def forecast_cached(entity_frame: pd.DataFrame, horizon: int):
    return fit_and_forecast(entity_frame, horizon=horizon)


def fmt_tonnes(value: float) -> str:
    return f"{value / 1000:,.2f} tCO₂e"


def make_chart_layout(fig, height=390):
    fig.update_layout(
        template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", height=height,
        margin=dict(l=12, r=12, t=28, b=12),
        font=dict(family="DM Sans, sans-serif", color="#dce9ed"),
        legend=dict(orientation="h", y=1.12),
    )
    fig.update_xaxes(showgrid=False, zeroline=False)
    fig.update_yaxes(gridcolor="rgba(150,190,200,.12)", zeroline=False)
    return fig


with st.sidebar:
    st.markdown("## Atlas controls")
    st.caption("Load public electricity data or bring a compatible CSV.")
    if st.button("Refresh public dataset", use_container_width=True):
        cached_public_data.clear(); forecast_cached.clear(); st.rerun()
    uploaded = st.file_uploader("Optional: upload compatible CSV", type=["csv"])
    st.divider()
    st.markdown("### EV scenario assumptions")
    annual_km = st.number_input("Annual distance per vehicle (km)", 1000, 100000, 15000, 1000)
    petrol_factor = st.number_input("Petrol emissions factor (kg CO₂e/km)", 0.01, 1.0, 0.192, 0.005, format="%.3f", help="Choose tailpipe-only or well-to-wheel and keep the boundary consistent.")
    petrol_upstream = st.number_input("Additional petrol upstream factor (kg/km)", 0.0, 0.5, 0.0, 0.005, format="%.3f")
    ev_consumption = st.number_input("EV electricity use (kWh/km)", 0.05, 0.60, 0.180, 0.01, format="%.3f")
    ev_upstream = st.number_input("EV charging lifecycle multiplier", 1.0, 1.5, 1.0, 0.05, help="Optional multiplier for grid-related upstream effects; 1.0 means none added.")
    manufacturing = st.number_input("Additional EV manufacturing emissions (kg CO₂e)", 0, 30000, 5000, 250, help="Incremental EV-minus-petrol manufacturing burden, not total EV manufacturing emissions.")
    lifetime = st.slider("Vehicle lifetime (years)", 3, 20, 12)
    st.divider()
    st.caption("All financial and vehicle inputs are scenario assumptions unless a source is explicitly provided.")

try:
    if uploaded is not None:
        data = normalize_electricity_data(pd.read_csv(uploaded))
        data_origin = f"User-uploaded file: {uploaded.name}"
    else:
        with st.spinner("Loading annual electricity lifecycle-intensity data..."):
            data = cached_public_data()
        data_origin = "Our World in Data Grapher · Ember electricity lifecycle-intensity series"
except Exception as exc:
    st.error("The electricity dataset could not be loaded or normalized.")
    st.exception(exc)
    st.info("Check your connection, refresh the dataset, or upload a CSV containing Entity, Year, and a lifecycle carbon-intensity column.")
    st.stop()

if data.empty:
    st.error("The selected dataset contains no usable observations."); st.stop()

countries = sorted(data["Entity"].dropna().unique().tolist())
preferred = [x for x in ["Canada", "United States", "United Kingdom", "Germany", "France", "Brazil", "India", "China"] if x in countries]
if not preferred:
    preferred = countries[:min(5, len(countries))]

# Persistent controls and region-specific modelling.
left, right = st.columns([1.1, 1])
with left:
    selected = st.selectbox("Primary region", countries, index=countries.index("Canada") if "Canada" in countries else 0)
with right:
    comparison = st.multiselect("Regions to compare", countries, default=preferred[:5])
forecast_horizon = st.slider("Forecast horizon (years)", 2, 15, 10)
region_data = data[data["Entity"] == selected].sort_values("Year")
if len(region_data) < 13:
    st.error(f"{selected} has only {len(region_data)} observations. At least 13 annual observations are required for this prototype's validation setup."); st.stop()
try:
    model, historical, forecast, metrics = forecast_cached(region_data, forecast_horizon)
except Exception as exc:
    st.error(f"Forecast could not be trained: {exc}"); st.stop()
latest = region_data.iloc[-1]

# Headline metrics
m1, m2, m3, m4 = st.columns(4)
m1.metric("Latest observed intensity", f"{latest['intensity_gco2_kwh']:,.0f} g/kWh")
m2.metric("Latest data year", str(int(latest["Year"])))
m3.metric("Selected forecast model", metrics["model"])
m4.metric("Holdout MAE", f"{metrics['mae']:,.1f} g/kWh", help=f"Persistence baseline MAE: {metrics['baseline_mae']:.1f} g/kWh")

# Main application sections
tabs = st.tabs(["Global Atlas", "Grid Future AI", "Fleet Lab", "Deployment Optimizer", "Strategy Report & Methods"])

with tabs[0]:
    st.subheader("01 · Global electricity atlas")
    st.markdown('<div class="small-note">Annual lifecycle carbon intensity of electricity generation, measured in grams of CO₂-equivalent per kilowatt-hour.</div>', unsafe_allow_html=True)
    latest_by_region = data.sort_values("Year").groupby("Entity", as_index=False).tail(1).copy()
    # Keep ISO-3-coded entities for the country choropleth; this avoids trying
    # to draw aggregate rows such as continents or the world as countries.
    if "Code" in latest_by_region.columns:
        mappable = latest_by_region["Code"].astype(str).str.fullmatch(r"[A-Z]{3}")
        if mappable.any():
            latest_by_region = latest_by_region[mappable].copy()
    latest_by_region["Latest year"] = latest_by_region["Year"].astype(str)
    map_col, info_col = st.columns([1.45, 1])
    with map_col:
        map_fig = px.choropleth(
            latest_by_region, locations="Entity", locationmode="country names",
            color="intensity_gco2_kwh", hover_name="Entity",
            hover_data={"Year": True, "intensity_gco2_kwh": ":.1f"},
            color_continuous_scale="Tealgrn",
            labels={"intensity_gco2_kwh": "gCO₂e/kWh", "Year": "Latest year"},
        )
        map_fig.update_geos(showframe=False, showcoastlines=True, coastlinecolor="#4b6872", bgcolor="rgba(0,0,0,0)")
        map_fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", height=440, margin=dict(l=0,r=0,t=15,b=0))
        st.plotly_chart(map_fig, use_container_width=True)
    with info_col:
        st.markdown("#### What the map shows")
        st.write("The most recent available observation for each geography in the selected dataset. Countries can have different latest data years; check the hover year before comparing.")
        st.metric("Geographies in dataset", f"{latest_by_region['Entity'].nunique():,}")
        st.metric("Selected region's latest value", f"{latest['intensity_gco2_kwh']:,.1f} g/kWh")
        st.caption("This is an annual average lifecycle intensity indicator, not a real-time marginal emissions rate for charging.")
    if comparison:
        comp = data[data["Entity"].isin(comparison)].copy()
        fig = px.line(comp, x="Year", y="intensity_gco2_kwh", color="Entity", markers=True,
                      labels={"intensity_gco2_kwh":"Lifecycle intensity (gCO₂e/kWh)", "Year":"Year", "Entity":"Region"})
        st.plotly_chart(make_chart_layout(fig, 370), use_container_width=True)
        st.dataframe(latest_by_region[latest_by_region["Entity"].isin(comparison)][["Entity","Year","intensity_gco2_kwh"]].sort_values("intensity_gco2_kwh"), hide_index=True, use_container_width=True)
    st.caption(f"Data: {data_origin}. Dataset units: gCO₂e/kWh.")

with tabs[1]:
    st.subheader("02 · Grid Future AI")
    st.write(f"**{selected}** · chronological holdout: {metrics['test_start']}–{metrics['test_end']} · {metrics['n_test']} test years · chosen model: **{metrics['model']}**")
    f = go.Figure()
    f.add_trace(go.Scatter(x=historical["Year"], y=historical["intensity_gco2_kwh"], mode="lines+markers", name="Observed", line=dict(color="#65d6b5", width=3)))
    f.add_trace(go.Scatter(x=forecast["Year"], y=forecast["upper_gco2_kwh"], mode="lines", line=dict(width=0), showlegend=False, hoverinfo="skip"))
    f.add_trace(go.Scatter(x=forecast["Year"], y=forecast["lower_gco2_kwh"], mode="lines", line=dict(width=0), fill="tonexty", fillcolor="rgba(231,196,124,.16)", name="Indicative residual band"))
    f.add_trace(go.Scatter(x=forecast["Year"], y=forecast["intensity_gco2_kwh"], mode="lines+markers", name="Forecast", line=dict(color="#e7c47c", width=3, dash="dash")))
    st.plotly_chart(make_chart_layout(f, 430), use_container_width=True)
    c1,c2,c3 = st.columns(3)
    c1.metric("Holdout MAE", f"{metrics['mae']:,.2f} g/kWh")
    c2.metric("Holdout RMSE", f"{metrics['rmse']:,.2f} g/kWh")
    c3.metric("Persistence MAE", f"{metrics['baseline_mae']:,.2f} g/kWh")
    st.markdown("#### Model comparison on the same future holdout")
    st.dataframe(metrics["leaderboard"].round(2), hide_index=True, use_container_width=True)
    st.download_button("Download forecast CSV", forecast.to_csv(index=False), file_name=f"{selected.lower().replace(' ','_')}_grid_forecast.csv", mime="text/csv")
    with st.expander("Validation design and interpretation"):
        st.write("The latest chronological observations are held out. Candidate models are trained only on earlier years and compared against a persistence baseline (predicting the next observation using the previous available observation). The best holdout-MAE model is then refit on all available history for recursive forecasts.")
        st.write("The shaded band is an empirical 90th-percentile absolute residual band from the holdout, widened by the square root of forecast horizon. It is a rough diagnostic range, not a calibrated prediction interval or guarantee.")
        st.warning("The models use year and lagged observed intensity only. They do not know future policy, planned generation projects, fuel prices, demand, weather, or grid dispatch. Forecasts are statistical extrapolations, not official energy-system scenarios.")

with tabs[2]:
    st.subheader("03 · Fleet Lab: lifecycle emissions and carbon payback")
    st.write("Adjust the assumptions in the sidebar. The manufacturing input is the *additional* upfront emissions of the EV relative to the petrol comparator.")
    grid_values = forecast["intensity_gco2_kwh"].astype(float).tolist()
    if len(grid_values) < lifetime:
        grid_values += [grid_values[-1]] * (lifetime - len(grid_values))
    lifecycle, payback = lifecycle_comparison(
        grid_values, annual_km, petrol_factor, ev_consumption, manufacturing, lifetime,
        petrol_upstream_kg_per_km=petrol_upstream, ev_upstream_multiplier=ev_upstream,
    )
    total_petrol = float(lifecycle["Petrol operational emissions (kgCO2e)"].sum())
    total_ev = float(lifecycle["EV charging emissions (kgCO2e)"].sum())
    net_total = float(lifecycle.iloc[-1]["Cumulative net savings (kgCO2e)"])
    a,b,c,d = st.columns(4)
    a.metric("Petrol use-phase emissions", fmt_tonnes(total_petrol))
    b.metric("EV charging emissions", fmt_tonnes(total_ev))
    c.metric("Net lifecycle savings", fmt_tonnes(net_total))
    d.metric("Carbon payback", f"Year {payback}" if payback else "Not within lifetime")
    line = go.Figure()
    line.add_hline(y=0, line_dash="dash", line_color="#e7c47c", annotation_text="Break-even")
    line.add_trace(go.Scatter(x=lifecycle["Year of ownership"], y=lifecycle["Cumulative net savings (kgCO2e)"], mode="lines+markers", name="Cumulative net savings", line=dict(color="#65d6b5", width=3), fill="tozeroy", fillcolor="rgba(101,214,181,.10)"))
    st.plotly_chart(make_chart_layout(line, 360), use_container_width=True)
    with st.expander("Annual calculation detail"):
        st.dataframe(lifecycle.round(2), hide_index=True, use_container_width=True)
    st.download_button("Download lifecycle calculation", lifecycle.to_csv(index=False), file_name="ev_lifecycle_comparison.csv", mime="text/csv")
    st.info("Boundary: petrol factor × distance, EV electricity use × grid intensity, plus the user-entered incremental manufacturing burden. If the petrol factor is tailpipe-only, upstream petrol emissions are excluded unless entered separately. Vehicle disposal, recycling credits, maintenance, road and charging infrastructure, and battery replacement are not automatically included.")

with tabs[3]:
    st.subheader("04 · Deployment optimizer")
    st.write("Allocate a limited vehicle-replacement budget across regions and deployment years to maximize estimated net CO₂e savings by a target year.")
    p1,p2,p3,p4 = st.columns(4)
    with p1: budget = st.number_input("Budget ($)", 10000, 500000000, 2500000, 25000)
    with p2: vehicle_cost = st.number_input("Cost per EV ($)", 1000, 500000, 55000, 1000)
    with p3: region_capacity = st.number_input("Max EVs per region", 1, 10000, 100)
    with p4: annual_capacity = st.number_input("Max deployments per year", 1, 50000, 100)
    opt_regions = st.multiselect("Candidate regions", countries, default=preferred[:min(5,len(preferred))], key="optimizer_regions")
    eligible_years = list(range(int(forecast["Year"].min()), int(forecast["Year"].max()) + 1))
    target_year = st.select_slider("Emissions accounting target year", options=eligible_years, value=eligible_years[min(5,len(eligible_years)-1)])
    deploy_end = min(target_year, eligible_years[0] + 4)
    deployment_years = list(range(eligible_years[0], deploy_end + 1))
    st.caption(f"Candidate deployment window: {deployment_years[0]}–{deployment_years[-1]}. Vehicles are integer decision variables; regional and annual capacities apply across selected options.")
    run_opt = st.button("Optimize deployment portfolio", type="primary", use_container_width=True)
    if run_opt:
        with st.spinner("Training region-specific models and solving the integer allocation..."):
            forecast_maps, current_maps, failures = {}, {}, []
            for region in opt_regions:
                rd = data[data["Entity"] == region].sort_values("Year")
                try:
                    _, rh, rf, rm = forecast_cached(rd, max(1, target_year - int(rd["Year"].max())))
                    fmap = {int(row.Year): float(row.intensity_gco2_kwh) for row in rf.itertuples()}
                    latest_row = rd.iloc[-1]
                    cmap = {year: float(latest_row["intensity_gco2_kwh"]) for year in fmap}
                    # Only forecast years after each region's own latest observation are eligible.
                    forecast_maps[region] = fmap
                    current_maps[region] = cmap
                except Exception as exc:
                    failures.append(f"{region}: {exc}")
            # Keep only years present in each region's forecast, never offset list indices.
            common_start = max((min(m) for m in forecast_maps.values() if m), default=10**9)
            years = [y for y in deployment_years if y >= common_start]
            if not forecast_maps or not years:
                st.error("No eligible forecast years were available for the selected regions. Choose regions with longer histories or a later deployment window.")
            else:
                kwargs = dict(target_year=target_year, vehicle_cost=vehicle_cost, annual_km=annual_km,
                              petrol_kg_per_km=petrol_factor, ev_kwh_per_km=ev_consumption,
                              additional_manufacturing_kg=manufacturing, max_vehicles_per_region=region_capacity,
                              petrol_upstream_kg_per_km=petrol_upstream, ev_upstream_multiplier=ev_upstream)
                f_options = build_options(forecast_maps, years, **kwargs)
                c_options = build_options(current_maps, years, **kwargs)
                f_choice, f_summary = optimize_allocation(f_options, budget, region_capacity, annual_capacity)
                c_choice, c_summary = optimize_allocation(c_options, budget, region_capacity, annual_capacity)
                st.session_state["atlas_opt_result"] = {
                    "forecast_choice": f_choice, "forecast_summary": f_summary,
                    "current_choice": c_choice, "current_summary": c_summary,
                    "failures": failures, "target_year": target_year,
                    "forecast_options": f_options,
                }
    result = st.session_state.get("atlas_opt_result")
    if result:
        fs, cs = result["forecast_summary"], result["current_summary"]
        if result["failures"]:
            st.warning("Some regions were excluded because they did not have enough usable history: " + "; ".join(result["failures"]))
        if result["forecast_choice"].empty:
            st.warning("The optimizer found no positive-savings allocation within the budget and capacity constraints.")
        else:
            q1,q2,q3,q4 = st.columns(4)
            q1.metric("Forecast-aware investment", f"${fs['spend']:,.0f}")
            q2.metric("Vehicles allocated", f"{fs['vehicles']:,}")
            q3.metric("Forecast-aware net savings", fmt_tonnes(fs["savings"]))
            q4.metric("Budget remaining", f"${budget-fs['spend']:,.0f}")
            delta = fs["savings"] - cs["savings"]
            st.markdown("#### Forecast-aware strategy vs. current-intensity strategy")
            compare_df = pd.DataFrame([
                {"Strategy":"Current-intensity", "Investment ($)":cs["spend"], "Vehicles":cs["vehicles"], "Estimated net savings (kgCO2e)":cs["savings"]},
                {"Strategy":"Forecast-aware", "Investment ($)":fs["spend"], "Vehicles":fs["vehicles"], "Estimated net savings (kgCO2e)":fs["savings"]},
            ])
            st.dataframe(compare_df.round(1), hide_index=True, use_container_width=True)
            st.metric("Difference in estimated net savings", fmt_tonnes(delta), delta=f"{delta/1000:+,.2f} tonnes vs current-intensity")
            st.caption("Both strategies use the same vehicle assumptions, target year, budget and capacity limits. The current-intensity case holds each region's latest observed grid intensity constant. The forecast-aware case uses the region-specific model forecasts. Neither is a real-world deployment guarantee.")
            st.markdown("#### Optimized forecast-aware allocation")
            st.dataframe(result["forecast_choice"].round(2), hide_index=True, use_container_width=True)
            st.download_button("Download optimized allocation CSV", result["forecast_choice"].to_csv(index=False), file_name="carbon_payback_atlas_optimized_allocation.csv", mime="text/csv")
            st.download_button("Download strategy comparison CSV", compare_df.to_csv(index=False), file_name="carbon_payback_atlas_strategy_comparison.csv", mime="text/csv")
            chart = px.bar(result["forecast_choice"], x="Region", y="Estimated net savings (kgCO2e)", color="Deployment year", barmode="group")
            st.plotly_chart(make_chart_layout(chart, 330), use_container_width=True)
        with st.expander("Optimization formulation"):
            st.latex(r"\max_{x_{r,t}\in\mathbb{Z}_{\geq 0}}\;\sum_{r,t} x_{r,t}\,s_{r,t}")
            st.latex(r"\text{subject to }\sum_{r,t}x_{r,t}c\leq B,\quad\sum_t x_{r,t}\leq K_r,\quad\sum_r x_{r,t}\leq C_t")
            st.write("Here x is the number of EVs assigned to a region and deployment year, s is estimated net lifecycle savings per EV by the target year, c is assumed purchase cost, B is the total budget, K is regional capacity, and C is annual deployment capacity. SciPy's HiGHS mixed-integer solver returns an integer allocation.")

with tabs[4]:
    st.subheader("05 · Strategy report and methodology")
    st.markdown("### Decision brief")
    st.write(f"**Question:** Where could an organization replacing petrol fleet vehicles with EVs achieve the largest estimated net emissions savings by its chosen target year?")
    st.write(f"**Primary analysis region:** {selected}. Latest observed grid intensity: {latest['intensity_gco2_kwh']:.1f} gCO₂e/kWh in {int(latest['Year'])}.")
    st.write(f"**Forecast method:** {metrics['model']}. Temporal holdout MAE: {metrics['mae']:.2f} gCO₂e/kWh; persistence baseline MAE: {metrics['baseline_mae']:.2f} gCO₂e/kWh.")
    st.write(f"**Fleet scenario:** {annual_km:,} km/year, {lifetime}-year life, petrol factor {petrol_factor:.3f} kgCO₂e/km, EV consumption {ev_consumption:.3f} kWh/km, and incremental manufacturing burden {manufacturing:,} kgCO₂e.")
    st.write(f"**Single-vehicle scenario result:** {fmt_tonnes(net_total)} estimated net savings over the modelled lifetime; payback: {f'year {payback}' if payback else 'not reached within the modelled lifetime'}.")
    report = f"""# Carbon Payback Atlas — Scenario Report

Generated: {datetime.now().astimezone().isoformat(timespec='minutes')}

## Scope
Decision-support scenario for EV fleet transitions. Outputs are estimates, not observed project outcomes or investment advice.

## Region and grid model
- Region: {selected}
- Latest observed grid intensity: {latest['intensity_gco2_kwh']:.2f} gCO2e/kWh ({int(latest['Year'])})
- Selected model: {metrics['model']}
- Chronological test period: {metrics['test_start']}–{metrics['test_end']} ({metrics['n_test']} observations)
- Holdout MAE: {metrics['mae']:.3f} gCO2e/kWh
- Persistence baseline MAE: {metrics['baseline_mae']:.3f} gCO2e/kWh

## Fleet assumptions
- Annual distance: {annual_km} km
- Vehicle lifetime: {lifetime} years
- Petrol factor: {petrol_factor} kgCO2e/km
- Additional petrol upstream factor: {petrol_upstream} kgCO2e/km
- EV consumption: {ev_consumption} kWh/km
- EV charging lifecycle multiplier: {ev_upstream}
- Incremental EV manufacturing burden: {manufacturing} kgCO2e

## Single-vehicle results
- Petrol use-phase emissions: {total_petrol:.2f} kgCO2e
- EV charging emissions: {total_ev:.2f} kgCO2e
- Net savings after incremental manufacturing: {net_total:.2f} kgCO2e
- Payback: {payback if payback else 'Not reached within lifetime'}

## Method limitations
The electricity forecast is a statistical extrapolation of annual average lifecycle intensity using year and lagged values. The empirical residual band is not a calibrated prediction interval. Lifecycle boundaries depend on user-specified factors. This analysis does not automatically include vehicle disposal, recycling credits, road infrastructure, maintenance, battery replacement, charging infrastructure, or marginal grid emissions.

## Data
{data_origin}
"""
    st.download_button("Download scenario report (Markdown)", report, file_name="carbon_payback_atlas_scenario_report.md", mime="text/markdown")
    st.markdown("### Assumptions and limitations")
    st.markdown("- **Observed vs predicted:** historical rows are source observations; future rows are model estimates. They are not blended.")
    st.markdown("- **Grid measure:** annual average lifecycle intensity; marginal emissions at the charging hour may differ.")
    st.markdown("- **Model:** lag-based statistical forecasting; no explicit policy, capacity expansion, demand, weather, or dispatch features.")
    st.markdown("- **Lifecycle:** manufacturing is incremental EV-minus-petrol burden; avoid entering total EV manufacturing emissions here.")
    st.markdown("- **Costs:** vehicle purchase cost is a user assumption and does not represent total cost of ownership, incentives, taxes, charging equipment, or operations.")
    st.markdown("- **Optimizer:** integer linear allocation under simplified budget and capacity constraints; its ranking depends on assumptions and data quality.")
    st.markdown("- **Interpretation:** results are screening estimates, not causal impact measurements, guaranteed savings, or procurement advice.")
    st.markdown("### Dataset provenance")
    st.write(data_origin)
    st.markdown("[Our World in Data electricity grapher](https://ourworldindata.org/grapher/electricity-mix?frequency=annual&metric=carbon_intensity&source=total)")

st.divider()
st.caption("Carbon Payback Atlas · Climate technology deployment intelligence · Educational research prototype · No real deployment or emissions reduction is claimed.")
